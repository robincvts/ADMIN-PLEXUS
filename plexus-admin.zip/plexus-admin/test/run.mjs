// Local checks against an in-memory store. Run: npm test
import assert from "node:assert/strict";
import { onRequest } from "../functions/[[path]].js";
import { encodePlaceId, resolvePlaceId } from "../src/clients.js";

class MockKV {
  constructor() { this.m = new Map(); }
  async get(k, o) {
    const e = this.m.get(k); if (!e) return null;
    return (o && o.type === "json") ? JSON.parse(e.v) : e.v;
  }
  async getWithMetadata(k) { const e = this.m.get(k); return e ? { value: e.v, metadata: e.meta } : { value: null, metadata: null }; }
  async put(k, v, o) {
    const stored = v instanceof Uint8Array ? v.buffer.slice(v.byteOffset, v.byteOffset + v.byteLength) : v;
    this.m.set(k, { v: stored, meta: o && o.metadata });
  }
  async delete(k) { this.m.delete(k); }
  async list({ prefix }) { return { keys: [...this.m.keys()].filter((k) => k.startsWith(prefix)).map((name) => ({ name })) }; }
}

const env = { CLIENTS: new MockKV(), ADMIN_PASSWORD: "s3cret" };
const origin = "https://links.example.in";
const auth = "Basic " + btoa("admin:s3cret");
const PNG = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==";

// Any network call during these tests is a bug.
globalThis.fetch = () => { throw new Error("unexpected network call"); };

async function call(path, { method = "GET", body, headers = {}, authed = true, admin = true } = {}) {
  const h = { ...headers };
  if (authed) h.Authorization = auth;
  if (admin && method !== "GET") { h["X-Requested-With"] = "plexus-admin"; h["Content-Type"] = "application/json"; }
  const request = new Request(origin + path, { method, headers: h, body: body ? JSON.stringify(body) : undefined, redirect: "manual" });
  return onRequest({ request, env });
}

let passed = 0;
const ok = (name) => { passed++; console.log("  ok  " + name); };

// place id encoding matches the one derived from the Yummin Maps link
assert.equal(encodePlaceId("39196300443739cd", "c24252fed781765c"), "ChIJzTk3RABjGTkRXHaB1_5SQsI");
assert.equal(await resolvePlaceId("https://www.google.com/maps/place/x/data=!1s0x39196300443739cd:0xc24252fed781765c"), "ChIJzTk3RABjGTkRXHaB1_5SQsI");
assert.equal(await resolvePlaceId("ChIJzTk3RABjGTkRXHaB1_5SQsI"), "ChIJzTk3RABjGTkRXHaB1_5SQsI");
await assert.rejects(() => resolvePlaceId("https://evil.example/0"), /Could not read/);
ok("place id encoding and link parsing");

// auth
{
  const noPw = await onRequest({ request: new Request(origin + "/admin"), env: { CLIENTS: env.CLIENTS } });
  assert.equal(noPw.status, 503);
  assert.equal((await call("/admin", { authed: false })).status, 401);
  const wrong = await onRequest({ request: new Request(origin + "/admin", { headers: { Authorization: "Basic " + btoa("a:nope") } }), env });
  assert.equal(wrong.status, 401);
  const good = await call("/admin");
  assert.equal(good.status, 200);
  assert.match(await good.text(), /Plexus Admin/);
  assert.equal((await call("/api/clients", { authed: false })).status, 401);
}
ok("admin and API need the password");

// create a client
const yummin = {
  name: "Yummin Cafe and Desserts", tagline: "", maps: "ChIJzTk3RABjGTkRXHaB1_5SQsI", instagram: "@yummin.in",
  whatsapp: "+91 88771 16603", message: "Hi Yummin, I'd like to know more.", theme: "berry", accent: "",
  links: [{ label: "Menu", url: "https://example.com/menu.pdf", icon: "menu" }, { label: "Call us", url: "+91 88771 16603", icon: "phone" }],
};
{
  const r = await call("/api/clients/yummin", { method: "PUT", body: { client: yummin, logo: PNG, banner: PNG } });
  assert.equal(r.status, 200);
  const d = await r.json();
  assert.equal(d.client.place_id, "ChIJzTk3RABjGTkRXHaB1_5SQsI");
  assert.equal(d.client.whatsapp, "918877116603");
  assert.equal(d.client.instagram, "yummin.in");
  assert.equal(d.client.links[1].url, "tel:+918877116603");
  assert.equal(d.client.hasLogo && d.client.hasBanner, true);
  assert.equal(d.urls.review, origin + "/yummin/review");
}
ok("publish a client with logo and banner");

// public page
{
  const r = await call("/yummin", { authed: false });
  assert.equal(r.status, 200);
  const t = await r.text();
  assert.match(t, /search\.google\.com\/local\/writereview\?placeid=ChIJzTk3RABjGTkRXHaB1_5SQsI/);
  assert.match(t, /instagram\.com\/yummin\.in\//);
  assert.match(t, /wa\.me\/918877116603\?text=Hi%20Yummin/);
  assert.match(t, /href="tel:\+918877116603"/);
  assert.match(t, /class="banner"/);
  assert.match(t, /\/yummin\/logo\?v=\d+/);
  assert.match(t, /Powered by <b>Plexus Technologies<\/b>/);
}
ok("public page has all buttons, banner, logo and credit");

// short links and images (no password needed)
{
  const rv = await call("/yummin/review", { authed: false });
  assert.equal(rv.status, 302);
  assert.match(rv.headers.get("location"), /writereview\?placeid=ChIJzTk3RABjGTkRXHaB1_5SQsI/);
  assert.match((await call("/yummin/insta", { authed: false })).headers.get("location"), /instagram\.com\/yummin\.in/);
  assert.match((await call("/yummin/chat/", { authed: false })).headers.get("location"), /wa\.me\/918877116603/);
  const img = await call("/yummin/logo", { authed: false });
  assert.equal(img.headers.get("content-type"), "image/png");
  assert.equal((await img.arrayBuffer()).byteLength, 70);
}
ok("short links redirect and images are served publicly");

// update keeps images, then removes the banner
{
  const r = await call("/api/clients/yummin", { method: "PUT", body: { client: { ...yummin, theme: "midnight", accent: "#FF8800" }, logo: "keep", banner: null } });
  const d = await r.json();
  assert.equal(d.client.hasLogo, true);
  assert.equal(d.client.hasBanner, false);
  const t = await (await call("/yummin", { authed: false })).text();
  assert.doesNotMatch(t, /class="banner"/);
  assert.match(t, /--accent: #FF8800/);
  assert.match(t, /color-scheme: dark/);
  assert.equal((await call("/yummin/banner", { authed: false })).status, 404);
}
ok("update keeps logo, removes banner, applies theme and accent");

// empty fields hide buttons
{
  await call("/api/clients/plain-shop", { method: "PUT", body: { client: { name: "Plain Shop", whatsapp: "9876543210" } } });
  const t = await (await call("/plain-shop", { authed: false })).text();
  assert.doesNotMatch(t, /Leave a Google review/);
  assert.doesNotMatch(t, /Follow on Instagram/);
  assert.match(t, /wa\.me\/919876543210/);
  assert.equal((await call("/plain-shop/review", { authed: false })).status, 404);
}
ok("empty fields hide their buttons (10-digit number gets +91)");

// validation and safety
{
  const put = (slug, client, extra = {}) => call("/api/clients/" + slug, { method: "PUT", body: { client, ...extra } });
  assert.equal((await put("Bad Slug", { name: "x" })).status, 400);
  assert.equal((await put("admin", { name: "x" })).status, 400);
  assert.equal((await put("ok-slug", { name: "" })).status, 400);
  assert.equal((await put("ok-slug", { name: "x", links: [{ label: "Bad", url: "javascript:alert(1)" }] })).status, 400);
  assert.equal((await put("ok-slug", { name: "x", whatsapp: "12" })).status, 400);
  assert.equal((await put("ok-slug", { name: "x" }, { logo: "data:text/html;base64,PHNjcmlwdD4=" })).status, 400);

  await put("xss-test", { name: '<script>alert(1)</script>', tagline: '"><img src=x onerror=alert(1)>' });
  const t = await (await call("/xss-test", { authed: false })).text();
  assert.doesNotMatch(t, /<script>alert/);
  assert.doesNotMatch(t, /<img src=x/);
  assert.match(t, /&lt;script&gt;alert\(1\)&lt;\/script&gt;/);

  const noHeader = await call("/api/clients/csrf", { method: "PUT", body: { client: { name: "x" } }, admin: false });
  assert.equal(noHeader.status, 403);
  const crossOrigin = await call("/api/clients/csrf", { method: "PUT", body: { client: { name: "x" } }, headers: { Origin: "https://evil.example" } });
  assert.equal(crossOrigin.status, 403);
}
ok("validation, HTML escaping and cross-site request blocking");

// preview does not touch the network and does not save
{
  const before = env.CLIENTS.m.size;
  const r = await call("/api/preview", { method: "POST", body: { client: { name: "Preview Co", maps: "https://maps.app.goo.gl/abc", theme: "ocean" }, logo: PNG } });
  assert.equal(r.status, 200);
  const t = await r.text();
  assert.match(t, /Preview Co/);
  assert.match(t, /data:image\/png;base64/);
  assert.equal(env.CLIENTS.m.size, before);
}
ok("preview renders without saving or calling Google");

// list, delete, unknown pages
{
  const list = await (await call("/api/clients")).json();
  assert.ok(list.clients.find((c) => c.slug === "yummin"));
  assert.equal((await call("/api/clients/yummin", { method: "DELETE" })).status, 200);
  assert.equal((await call("/yummin", { authed: false })).status, 404);
  assert.equal((await call("/yummin/logo", { authed: false })).status, 404);
  assert.equal((await call("/nothing-here", { authed: false })).status, 404);
  assert.equal((await call("/", { authed: false })).status, 200);
}
ok("list, delete and 404 pages");

// website and client pages on separate hostnames
{
  const kv = new MockKV();
  const env2 = { CLIENTS: kv, ADMIN_PASSWORD: "s3cret", CLIENT_HOST: "go.plexus.example" };
  const site = () => new Response("WEBSITE", { status: 200 });
  const hit = (host, path, headers = {}) =>
    onRequest({ request: new Request(`https://${host}${path}`, { headers }), env: env2, next: site });

  const put = await onRequest({
    request: new Request("https://go.plexus.example/api/clients/cafe-k7x2", {
      method: "PUT",
      headers: { Authorization: auth, "X-Requested-With": "plexus-admin", "Content-Type": "application/json" },
      body: JSON.stringify({ client: { name: "Cafe", whatsapp: "9876543210" } }),
    }),
    env: env2, next: site,
  });
  assert.equal(put.status, 200);

  // client host serves the client page; admin needs the password
  assert.equal((await hit("go.plexus.example", "/cafe-k7x2")).status, 200);
  assert.equal((await hit("GO.plexus.example", "/cafe-k7x2")).status, 200);
  assert.equal((await hit("go.plexus.example", "/admin")).status, 401);
  assert.match(await (await hit("go.plexus.example", "/robots.txt")).text(), /Disallow: \//);
  assert.equal((await hit("go.plexus.example", "/cafe-k7x2")).headers.get("x-robots-tag"), "noindex, nofollow");

  // any other hostname (main website, pages.dev) only ever gets the website
  for (const host of ["plexus.example", "www.plexus.example", "plexus-links.pages.dev"]) {
    for (const path of ["/", "/cafe-k7x2", "/cafe-k7x2/review", "/cafe-k7x2/logo", "/admin", "/api/clients"]) {
      const r = await hit(host, path, { Authorization: auth });
      assert.equal(await r.text(), "WEBSITE", host + path);
    }
  }
}
ok("client pages and admin are only served on the client hostname");

console.log(`\n${passed} checks passed`);
