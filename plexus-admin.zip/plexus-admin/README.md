# Plexus link pages: admin panel

Open `go.yourdomain.in/admin`, fill in a client's details, press **Publish**. Their page is live straight away at `go.yourdomain.in/<page-name>`.

What you can set per client: business name, page name (web address), tagline, logo, banner, Google review button, Instagram, WhatsApp (with starting message), up to 6 extra buttons (menu, website, call, location, order), and a theme with an optional custom button colour. The form has a live phone preview.

Each client also gets short links for QR codes:
`/<name>/review`, `/<name>/insta`, `/<name>/chat`

It runs on Cloudflare Pages (free plan is enough). Customers never see the admin page; it needs your password.

## One-time setup (about 15 minutes)

You need: a free Cloudflare account, and Node.js 18 or newer on your computer.

1. Open a terminal in this folder and run `npm install`.
2. Log in: `npx wrangler login`
3. Create the storage: `npx wrangler kv namespace create CLIENTS`
   Copy the `id` it prints into `wrangler.toml`, replacing `REPLACE_WITH_YOUR_KV_NAMESPACE_ID`.
4. Create the site: `npx wrangler pages project create plexus-links --production-branch main`
5. Set your admin password: `npx wrangler pages secret put ADMIN_PASSWORD --project-name plexus-links`
   Type a long password when asked. Use this password when your browser asks at `/admin` (any username works).
6. Publish: `npm run deploy`
7. Your site is now at `plexus-links.pages.dev`. Open `/admin`.
8. Add two custom domains in the Cloudflare dashboard (Workers & Pages, plexus-links, Custom domains):
   - `plexustechnologies.in` for your public website
   - `go.plexustechnologies.in` for client pages and the admin
   If you use another domain, change `CLIENT_HOST` in `wrangler.toml` to match, then run `npm run deploy` again.

## Public website and client pages are kept apart
- Your website (about, services, pricing, contact, blog) lives in the `public/` folder and is served on `plexustechnologies.in`. Edit `public/index.html` or add pages there.
- Client pages, short links and `/admin` are served only on `go.plexustechnologies.in`. On every other address, including the default `plexus-links.pages.dev`, they do not exist.
- The website has no list of clients and links to none. Client pages are marked "do not index", so Google will not list them.
- New page names get a random ending, for example `yummin-k7x2`, so nobody can guess a client's address.

## QR cards and NFC tags
Write the client's short link to the card or tag, for example `https://go.plexustechnologies.in/yummin-k7x2/review` for a review card, or the page address `https://go.plexustechnologies.in/yummin-k7x2` for a full link page. NFC tags store the same address as a QR code does. Because these addresses point to your domain, you can change where they lead later without replacing a card.

To publish code changes later, run `npm run deploy` again. Client data is stored separately and is not touched.

## Using it
- **New client:** choose "+ New client", fill the form, press Publish. Copy the links shown afterwards.
- **Edit a client:** pick them from the dropdown at the top right, change anything, Publish again.
- **Google review button:** paste the business's Google Maps share link. The page name cannot be changed after publishing because printed QR codes depend on it.
- **Hide a button:** leave its field empty.

## Notes
- Test each client's review link once on a phone before printing QR codes.
- Photos are resized in the browser before upload, so large camera photos are fine.
- Free plan limits are far above what a few hundred clients need (100,000 page loads per day, 1,000 saves per day).
- `npm test` runs the automated checks. After editing `src/admin.html`, run `npm run embed` (deploy does this for you).

## Files
- `functions/[[path]].js` the whole backend: routes, saving, password check
- `src/render.js` the client page design and themes
- `src/admin.html` the admin form
- `src/clients.js` validation and Google Maps link handling
