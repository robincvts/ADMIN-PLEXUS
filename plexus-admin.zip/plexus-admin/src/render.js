// Renders a client's public link page. One source of truth for the live site and the admin preview.

export const THEMES = {
  berry:    { label: "Berry",    bg: "#FFF5F6", surface: "#FFFFFF", fg: "#2A1519", muted: "#7A5A60", line: "#F0D9DD", accent: "#C4204F", ig: "#C2306F", wa: "#12935A" },
  ocean:    { label: "Ocean",    bg: "#F0F6FB", surface: "#FFFFFF", fg: "#0E2233", muted: "#566C80", line: "#D5E3EF", accent: "#1664C0", ig: "#C2306F", wa: "#12935A" },
  forest:   { label: "Forest",   bg: "#F2F7F1", surface: "#FFFFFF", fg: "#14261A", muted: "#587060", line: "#D8E5D6", accent: "#2E7D4F", ig: "#C2306F", wa: "#12935A" },
  sunset:   { label: "Sunset",   bg: "#FFF6EC", surface: "#FFFFFF", fg: "#2B1A0E", muted: "#7D6450", line: "#F1DEC8", accent: "#D9560B", ig: "#C2306F", wa: "#12935A" },
  mono:     { label: "Mono",     bg: "#F4F4F5", surface: "#FFFFFF", fg: "#111111", muted: "#66666B", line: "#DDDDE0", accent: "#111111", ig: "#C2306F", wa: "#12935A" },
  midnight: { label: "Midnight", bg: "#0F1620", surface: "#18222F", fg: "#EEF2F7", muted: "#93A1B3", line: "#263243", accent: "#7AA2FF", ig: "#FF6FA8", wa: "#3DD08C" },
};

export const ICONS = {
  link:  '<path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1"/><path d="M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/>',
  menu:  '<path d="M4 5a2 2 0 0 1 2-2h13v16H6a2 2 0 0 0-2 2V5z"/><path d="M8 7h7M8 11h7"/>',
  phone: '<path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2z"/>',
  pin:   '<path d="M12 21s7-6.2 7-11.5A7 7 0 0 0 5 9.5C5 14.8 12 21 12 21z"/><circle cx="12" cy="9.5" r="2.5"/>',
  globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3.5 3 14.5 0 18M12 3c-3 3.5-3 14.5 0 18"/>',
  bag:   '<path d="M5 8h14l-1 12H6L5 8z"/><path d="M9 8V6a3 3 0 0 1 6 0v2"/>',
};

export const esc = (s) =>
  String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

function luminance(hex) {
  const n = parseInt(hex.slice(1), 16);
  const ch = [(n >> 16) & 255, (n >> 8) & 255, n & 255].map((v) => {
    v /= 255;
    return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
  });
  return 0.2126 * ch[0] + 0.7152 * ch[1] + 0.0722 * ch[2];
}

export function waDisplay(wa) {
  return wa.length > 10 ? `+${wa.slice(0, -10)} ${wa.slice(-10, -5)} ${wa.slice(-5)}` : wa;
}

export function reviewUrl(c) {
  return c.place_id ? "https://search.google.com/local/writereview?placeid=" + encodeURIComponent(c.place_id) : "";
}
export function instaUrl(c) {
  return c.instagram ? `https://www.instagram.com/${encodeURIComponent(c.instagram)}/` : "";
}
export function waUrl(c) {
  if (!c.whatsapp) return "";
  return "https://wa.me/" + c.whatsapp + (c.message ? "?text=" + encodeURIComponent(c.message) : "");
}

const ARROW =
  '<svg class="go" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M7 17L17 7M8 7h9v9"/></svg>';
const STAR = '<svg viewBox="0 0 24 24"><path d="M12 2.5l2.9 6.1 6.6.8-4.9 4.6 1.3 6.6L12 17.3 6.1 20.6l1.3-6.6L2.5 9.4l6.6-.8L12 2.5z"/></svg>';

function row({ id, href, icon, title, sub, primary, extra }) {
  return `
    <a class="row${primary ? " primary" : ""}"${id ? ` id="${id}"` : ""} href="${esc(href)}" target="_blank" rel="noopener">
      <span class="ico" aria-hidden="true">${icon}</span>
      <span class="t"><b>${esc(title)}</b><span>${esc(sub)}</span>${extra || ""}</span>
      ${ARROW}
    </a>`;
}

/**
 * images: optional overrides for the preview. A string is a data URL, null means "no image".
 * When a key is absent, the stored image (if any) is used through /<slug>/logo and /<slug>/banner.
 */
export function renderPage(c, images = {}) {
  const t = THEMES[c.theme] || THEMES.berry;
  const accent = /^#[0-9A-Fa-f]{6}$/.test(c.accent || "") ? c.accent : t.accent;
  const accentFg = luminance(accent) > 0.4 ? "#161616" : "#FFFFFF";
  const v = c.updated ? `?v=${c.updated}` : "";

  const logoSrc = "logo" in images ? images.logo : c.hasLogo ? `/${c.slug}/logo${v}` : null;
  const bannerSrc = "banner" in images ? images.banner : c.hasBanner ? `/${c.slug}/banner${v}` : null;

  const logoInner = logoSrc
    ? `<img src="${esc(logoSrc)}" alt="${esc(c.name)} logo">`
    : `<span aria-hidden="true">${esc([...c.name][0].toUpperCase())}</span>`;

  const rows = [];
  if (c.place_id) {
    rows.push(
      row({
        id: "review", href: reviewUrl(c), primary: true,
        icon: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2.5l2.9 6.1 6.6.8-4.9 4.6 1.3 6.6L12 17.3 6.1 20.6l1.3-6.6L2.5 9.4l6.6-.8L12 2.5z"/></svg>',
        title: "Leave a Google review", sub: "Takes under a minute",
        extra: `<span class="stars" aria-hidden="true">${STAR.repeat(5)}</span>`,
      })
    );
  }
  if (c.instagram) {
    rows.push(
      row({
        id: "ig", href: instaUrl(c),
        icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.3" cy="6.7" r="1" fill="currentColor" stroke="none"/></svg>',
        title: "Follow on Instagram", sub: "@" + c.instagram,
      })
    );
  }
  if (c.whatsapp) {
    rows.push(
      row({
        id: "wa", href: waUrl(c),
        icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.5 11.5a8.5 8.5 0 0 1-12.6 7.4L3.5 20.5l1.6-4.2A8.5 8.5 0 1 1 20.5 11.5z"/><path d="M9 8.8c.3 2.6 2.6 5 5.3 5.5l1.3-1.2-1.9-1-.9.7c-.9-.4-1.7-1.2-2.1-2.1l.7-.9-1-1.9L9 8.8z" fill="currentColor" stroke="none"/></svg>',
        title: "Chat on WhatsApp", sub: waDisplay(c.whatsapp),
      })
    );
  }
  for (const l of c.links || []) {
    const path = ICONS[l.icon] || ICONS.link;
    let sub = "Open";
    try {
      sub = l.url.startsWith("tel:") ? l.url.slice(4) : new URL(l.url).hostname.replace(/^www\./, "");
    } catch {}
    rows.push(
      row({
        href: l.url, title: l.label, sub,
        icon: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${path}</svg>`,
      })
    );
  }

  const tagline = c.tagline || "Tell us how we did, follow our work, or message us directly.";

  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="${t.bg}">
<meta name="robots" content="noindex">
<title>${esc(c.name)}</title>
<meta name="description" content="Review, follow and message ${esc(c.name)}.">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,600;12..96,700&family=DM+Sans:wght@400;500;600&display=swap">
<style>
  :root {
    color-scheme: ${t.bg === "#0F1620" ? "dark" : "light"};
    --bg: ${t.bg}; --surface: ${t.surface}; --fg: ${t.fg}; --muted: ${t.muted}; --line: ${t.line};
    --accent: ${accent}; --accent-fg: ${accentFg}; --star: #F5B301; --wa: ${t.wa}; --ig: ${t.ig};
    --font-display: "Bricolage Grotesque", "Avenir Next", "Segoe UI", system-ui, sans-serif;
    --font-body: "DM Sans", "Segoe UI", system-ui, sans-serif;
  }
  * { box-sizing: border-box; }
  html, body { min-height: 100%; margin: 0; }
  body {
    background: var(--bg); color: var(--fg); font-family: var(--font-body); font-size: 16px; line-height: 1.5;
    padding-block: ${bannerSrc ? "16px" : "40px"} 28px;
    padding-left: max(16px, env(safe-area-inset-left, 0px));
    padding-right: max(16px, env(safe-area-inset-right, 0px));
  }
  .wrap { max-width: 440px; margin-inline: auto; display: flex; flex-direction: column; gap: 28px; min-height: calc(100vh - 44px); }
  .banner { width: 100%; aspect-ratio: 3 / 1; border-radius: 20px; overflow: hidden; background: var(--line); }
  .banner img { width: 100%; height: 100%; object-fit: cover; display: block; }
  header { display: flex; flex-direction: column; align-items: center; text-align: center; gap: 10px; }
  .logo {
    width: 116px; height: 116px; border-radius: 50%; background: var(--accent); color: var(--accent-fg);
    display: grid; place-items: center; overflow: hidden; border: 4px solid var(--bg);
    box-shadow: 0 0 0 1px var(--line), 0 10px 24px color-mix(in srgb, var(--accent) 20%, transparent);
    margin-bottom: 6px;${bannerSrc ? " margin-top: -74px;" : ""}
  }
  .logo img { width: 100%; height: 100%; object-fit: cover; display: block; }
  .logo span { font-family: var(--font-display); font-weight: 700; font-size: 56px; line-height: 1; }
  .eyebrow { font-size: 12px; font-weight: 600; letter-spacing: .12em; text-transform: uppercase; color: var(--muted); }
  h1 { font-family: var(--font-display); font-weight: 700; font-size: clamp(30px, 9vw, 40px); line-height: 1.05; letter-spacing: -.02em; margin: 0; text-wrap: balance; overflow-wrap: anywhere; }
  .lede { margin: 0 auto; color: var(--muted); max-width: 34ch; }
  nav { display: flex; flex-direction: column; gap: 12px; }
  .row {
    display: grid; grid-template-columns: 48px minmax(0, 1fr) auto; align-items: center; gap: 14px; padding: 16px;
    border-radius: 16px; background: var(--surface); border: 1px solid var(--line); color: var(--fg); text-decoration: none;
    transition: transform .15s ease, border-color .15s ease;
  }
  .row:hover { border-color: var(--fg); }
  .row:active { transform: scale(.985); }
  .row:focus-visible { outline: 3px solid var(--accent); outline-offset: 3px; }
  .row .ico { width: 48px; height: 48px; border-radius: 12px; display: grid; place-items: center; background: var(--bg); color: var(--accent); }
  .row .ico svg { width: 24px; height: 24px; }
  .row .t { display: flex; flex-direction: column; min-width: 0; }
  .row .t b { font-family: var(--font-display); font-size: 19px; font-weight: 600; letter-spacing: -.01em; line-height: 1.2; overflow-wrap: anywhere; }
  .row .t > span { font-size: 14px; color: var(--muted); overflow-wrap: anywhere; }
  .row .go { width: 20px; height: 20px; color: var(--muted); }
  .row.primary { background: var(--accent); border-color: var(--accent); color: var(--accent-fg); padding-block: 20px; }
  .row.primary:hover { border-color: var(--accent); filter: brightness(1.06); }
  .row.primary .ico { background: rgba(255,255,255,.18); color: var(--accent-fg); }
  .row.primary .t > span, .row.primary .go { color: var(--accent-fg); opacity: .85; }
  .stars { display: flex; gap: 2px; margin-top: 4px; }
  .stars svg { width: 15px; height: 15px; fill: var(--star); }
  #ig .ico { color: var(--ig); }
  #wa .ico { color: var(--wa); }
  footer { margin-top: auto; text-align: center; font-size: 13px; color: var(--muted); border-top: 1px solid var(--line); padding-block: 18px 0; }
  footer b { color: var(--fg); font-weight: 600; }
  @media (prefers-reduced-motion: reduce) { .row { transition: none; } }
</style>
</head>
<body>
<main class="wrap">
  ${bannerSrc ? `<div class="banner"><img src="${esc(bannerSrc)}" alt=""></div>` : ""}
  <header>
    <div class="logo">${logoInner}</div>
    <div class="eyebrow">Thank you for visiting</div>
    <h1>${esc(c.name)}</h1>
    <p class="lede">${esc(tagline)}</p>
  </header>
  <nav aria-label="Links">${rows.join("")}
  </nav>
  <footer>Powered by <b>Plexus Technologies</b></footer>
</main>
</body>
</html>`;
}

export function landingPage() {
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex"><title>Plexus Technologies</title>
<style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#F3F5F8;color:#0E1A2B;font-family:"Segoe UI",system-ui,sans-serif;text-align:center;padding:24px}h1{font-size:28px;margin:0 0 6px}p{margin:0;color:#5A677A}</style></head>
<body><main><h1>Plexus Technologies</h1><p>Smart link pages for local businesses.</p></main></body></html>`;
}

export function notFoundPage() {
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex"><title>Page not found</title>
<style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#F3F5F8;color:#0E1A2B;font-family:"Segoe UI",system-ui,sans-serif;text-align:center;padding:24px}h1{font-size:24px;margin:0 0 6px}p{margin:0;color:#5A677A}</style></head>
<body><main><h1>Page not found</h1><p>Check the link and try again.</p></main></body></html>`;
}
