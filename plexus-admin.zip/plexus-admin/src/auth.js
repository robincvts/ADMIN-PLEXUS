// Password check for the admin page and API (HTTP Basic auth; the username is ignored).

function safeEqual(a, b) {
  const enc = new TextEncoder();
  const x = enc.encode(a);
  const y = enc.encode(b);
  let diff = x.length ^ y.length;
  const n = Math.max(x.length, y.length);
  for (let i = 0; i < n; i++) diff |= (x[i] ?? 0) ^ (y[i] ?? 0);
  return diff === 0;
}

/** Returns "ok", "denied" or "unset" (no ADMIN_PASSWORD configured). */
export function checkAuth(request, env) {
  if (!env.ADMIN_PASSWORD) return "unset";
  const h = request.headers.get("Authorization") || "";
  if (!h.startsWith("Basic ")) return "denied";
  let decoded;
  try {
    decoded = atob(h.slice(6));
  } catch {
    return "denied";
  }
  const i = decoded.indexOf(":");
  const pass = i >= 0 ? decoded.slice(i + 1) : decoded;
  return safeEqual(pass, env.ADMIN_PASSWORD) ? "ok" : "denied";
}
