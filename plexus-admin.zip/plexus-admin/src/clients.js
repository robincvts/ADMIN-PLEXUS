// Validation and helpers for client records.
import { THEMES, ICONS } from "./render.js";

export const RESERVED = new Set(["admin", "api", "assets", "static", "favicon.ico", "robots.txt"]);
const SLUG = /^[a-z0-9][a-z0-9-]{1,39}$/;
const HEX = /^#[0-9A-Fa-f]{6}$/;

export class BadRequest extends Error {}
const bad = (m) => new BadRequest(m);

export function validSlug(slug) {
  return SLUG.test(slug) && !RESERVED.has(slug);
}

const clip = (s, n) => String(s ?? "").trim().slice(0, n);

/** Google's feature id (0x..:0x..) to the ChIJ place id that the review link needs. */
export function encodePlaceId(hexA, hexB) {
  const bytes = [0x0a, 0x12, 0x09];
  const push = (hex) => {
    let n = BigInt("0x" + hex.padStart(16, "0"));
    for (let i = 0; i < 8; i++) {
      bytes.push(Number(n & 0xffn));
      n >>= 8n;
    }
  };
  push(hexA);
  bytes.push(0x11);
  push(hexB);
  let bin = "";
  for (const b of bytes) bin += String.fromCharCode(b);
  return btoa(bin).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

const GOOGLE_HOST = /^https:\/\/(maps\.app\.goo\.gl|goo\.gl|www\.google\.[a-z.]+|maps\.google\.[a-z.]+|google\.[a-z.]+)\//i;

export async function resolvePlaceId(input, fetchImpl = fetch) {
  let u = String(input || "").trim();
  if (/^ChIJ[\w-]{20,}$/.test(u)) return u;
  for (let i = 0; i < 6; i++) {
    const m = u.match(/0x([0-9a-f]{1,16}):0x([0-9a-f]{1,16})/i);
    if (m) return encodePlaceId(m[1], m[2]);
    if (!GOOGLE_HOST.test(u)) break;
    const r = await fetchImpl(u, { redirect: "manual" });
    const loc = r.headers.get("location");
    if (!loc) break;
    u = new URL(loc, u).href;
  }
  throw bad("Could not read a Place ID from that Maps link. Paste the full link from Google Maps (Share, then Copy link), or a Place ID starting with ChIJ.");
}

function parseInstagram(s) {
  let h = String(s || "").trim();
  const m = h.match(/instagram\.com\/([A-Za-z0-9._]+)/i);
  if (m) h = m[1];
  h = h.replace(/^@/, "");
  if (!h) return "";
  if (!/^[A-Za-z0-9._]{1,30}$/.test(h)) throw bad("Instagram handle looks wrong. Use letters, numbers, dots and underscores only.");
  return h;
}

function parseWhatsapp(s) {
  let d = String(s || "").replace(/\D/g, "");
  if (!d) return "";
  if (d.length === 10) d = "91" + d; // assume India when no country code is given
  if (d.length < 11 || d.length > 15) throw bad("WhatsApp number looks wrong. Include the country code, for example 91 88771 16603.");
  return d;
}

function parseLinks(arr) {
  if (!Array.isArray(arr)) return [];
  if (arr.length > 6) throw bad("You can add up to 6 extra buttons.");
  return arr
    .filter((l) => l && (l.label || l.url))
    .map((l) => {
      const label = clip(l.label, 40);
      let url = clip(l.url, 500);
      if (!label) throw bad("Every extra button needs a label.");
      if (/^\+?[\d\s-]{7,}$/.test(url)) url = "tel:" + url.replace(/[^\d+]/g, ""); // bare phone number
      if (!/^https:\/\//i.test(url) && !/^tel:\+?\d{7,15}$/.test(url)) {
        throw bad(`The link for "${label}" must start with https:// or be a phone number.`);
      }
      const icon = ICONS[l.icon] ? l.icon : "link";
      return { label, url, icon };
    });
}

/** Turns form input into a clean stored record. Throws BadRequest with a readable message. */
export async function sanitizeClient(input, slug, existing, fetchImpl) {
  const name = clip(input.name, 80);
  if (!name) throw bad("Business name is required.");

  const theme = THEMES[input.theme] ? input.theme : "berry";
  const accent = HEX.test(input.accent || "") ? input.accent : "";

  const maps = clip(input.maps, 600);
  let place_id = existing?.place_id || "";
  if (!maps) place_id = "";
  else if (!existing || maps !== existing.maps || !place_id) place_id = await resolvePlaceId(maps, fetchImpl);

  return {
    slug,
    name,
    tagline: clip(input.tagline, 120),
    maps,
    place_id,
    instagram: parseInstagram(input.instagram),
    whatsapp: parseWhatsapp(input.whatsapp),
    message: clip(input.message, 200),
    theme,
    accent,
    links: parseLinks(input.links),
    hasLogo: !!existing?.hasLogo,
    hasBanner: !!existing?.hasBanner,
    updated: Date.now(),
  };
}

/** Decodes an image data URL. Returns { bytes, type } or throws. */
export function decodeImage(dataUrl) {
  const m = /^data:(image\/(?:png|jpeg|webp));base64,([A-Za-z0-9+/=]+)$/.exec(dataUrl || "");
  if (!m) throw bad("Images must be PNG, JPG or WebP.");
  const bin = atob(m[2]);
  if (bin.length > 900_000) throw bad("That image is too large. Try a smaller one.");
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return { bytes, type: m[1] };
}
