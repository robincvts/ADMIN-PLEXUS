// Single entry point for the whole site (Cloudflare Pages Functions).
//   /                       landing page
//   /admin                  admin page (password)
//   /api/...                admin API (password)
//   /<slug>                 a client's public page
//   /<slug>/review|insta|chat   short links for QR codes
//   /<slug>/logo|banner     stored images

import { renderPage, landingPage, notFoundPage, THEMES, ICONS, reviewUrl, instaUrl, waUrl } from "../src/render.js";
import { sanitizeClient, decodeImage, resolvePlaceId, validSlug, BadRequest } from "../src/clients.js";
import { checkAuth } from "../src/auth.js";
import { ADMIN_HTML } from "../src/admin-html.js";

const BASE_HEADERS = { "X-Content-Type-Options": "nosniff", "Referrer-Policy": "strict-origin-when-cross-origin" };

const html = (body, status = 200, cache = "no-store") =>
  new Response(body, {
    status,
    headers: { ...BASE_HEADERS, "Content-Type": "text/html; charset=utf-8", "Cache-Control": cache, "X-Robots-Tag": "noindex, nofollow" },
  });
const json = (data, status = 200) =>
  new Response(JSON.stringify(data), { status, headers: { ...BASE_HEADERS, "Content-Type": "application/json", "Cache-Control": "no-store" } });

async function getClient(env, slug) {
  return env.CLIENTS.get(`client:${slug}`, { type: "json" });
}

function summary(c) {
  return { slug: c.slug, name: c.name, theme: c.theme, updated: c.updated };
}

async function handleApi(request, env, url, parts) {
  if (request.method !== "GET") {
    const origin = request.headers.get("Origin");
    if (origin && origin !== url.origin) return json({ error: "Request blocked." }, 403);
    if (request.headers.get("X-Requested-With") !== "plexus-admin") return json({ error: "Request blocked." }, 403);
  }

  const [, resource, slug] = parts;

  try {
    if (resource === "meta" && request.method === "GET") {
      return json({ themes: THEMES, icons: Object.keys(ICONS) });
    }

    if (resource === "resolve" && request.method === "POST") {
      const { link } = await request.json();
      return json({ place_id: await resolvePlaceId(link) });
    }

    if (resource === "preview" && request.method === "POST") {
      const body = await request.json();
      // The stub "existing" record stops sanitizeClient from calling Google on every preview.
      const stub = { maps: String(body.client?.maps || "").trim().slice(0, 600), place_id: "preview" };
      const c = await sanitizeClient(body.client || {}, "preview", stub);
      c.slug = validSlug(body.client?.slug || "") ? body.client.slug : "preview";
      c.hasLogo = !!body.client?.hasLogo;
      c.hasBanner = !!body.client?.hasBanner;
      c.updated = body.client?.updated || 0;
      c.place_id = c.maps ? "preview" : "";
      const images = {};
      if ("logo" in body) images.logo = body.logo;
      if ("banner" in body) images.banner = body.banner;
      return html(renderPage(c, images));
    }

    if (resource === "clients" && !slug && request.method === "GET") {
      const list = await env.CLIENTS.list({ prefix: "client:" });
      const clients = [];
      for (const k of list.keys) {
        const c = await env.CLIENTS.get(k.name, { type: "json" });
        if (c) clients.push(summary(c));
      }
      clients.sort((a, b) => b.updated - a.updated);
      return json({ clients });
    }

    if (resource === "clients" && slug) {
      if (!validSlug(slug)) return json({ error: "The page name can use lowercase letters, numbers and hyphens (2 to 40 characters)." }, 400);

      if (request.method === "GET") {
        const c = await getClient(env, slug);
        return c ? json({ client: c }) : json({ error: "Not found." }, 404);
      }

      if (request.method === "PUT") {
        const body = await request.json();
        const existing = await getClient(env, slug);
        const c = await sanitizeClient(body.client || {}, slug, existing);

        // Images: undefined or "keep" leaves the stored image alone, null removes it, a data URL replaces it.
        for (const [field, flag] of [["logo", "hasLogo"], ["banner", "hasBanner"]]) {
          const v = body[field];
          const key = `img:${slug}:${field}`;
          if (v === null) {
            await env.CLIENTS.delete(key);
            c[flag] = false;
          } else if (typeof v === "string" && v !== "keep") {
            const { bytes, type } = decodeImage(v);
            await env.CLIENTS.put(key, bytes, { metadata: { type } });
            c[flag] = true;
          }
        }

        await env.CLIENTS.put(`client:${slug}`, JSON.stringify(c));
        const base = `${url.origin}/${slug}`;
        return json({ ok: true, client: c, urls: { page: base, review: base + "/review", insta: base + "/insta", chat: base + "/chat" } });
      }

      if (request.method === "DELETE") {
        await env.CLIENTS.delete(`client:${slug}`);
        await env.CLIENTS.delete(`img:${slug}:logo`);
        await env.CLIENTS.delete(`img:${slug}:banner`);
        return json({ ok: true });
      }
    }

    return json({ error: "Not found." }, 404);
  } catch (e) {
    if (e instanceof BadRequest) return json({ error: e.message }, 400);
    console.error(e);
    return json({ error: "Something went wrong on the server. Try again." }, 500);
  }
}

export async function onRequest(context) {
  const { request, env } = context;
  const url = new URL(request.url);

  // The public website and the client pages live on different hostnames. Only CLIENT_HOST serves
  // client pages and the admin; every other hostname gets the static website from public/.
  // The website never lists or links to client pages.
  if (env.CLIENT_HOST && url.hostname.toLowerCase() !== env.CLIENT_HOST.toLowerCase()) return context.next();

  const parts = url.pathname.split("/").filter(Boolean);

  if (parts[0] === "robots.txt") {
    return new Response("User-agent: *\nDisallow: /\n", { headers: { ...BASE_HEADERS, "Content-Type": "text/plain" } });
  }

  if (parts.length === 0) return html(landingPage(), 200, "public, max-age=300");

  if (!env.CLIENTS) return html("<h1>Setup incomplete</h1><p>The CLIENTS storage binding is missing. See README step 3.</p>", 503);

  const first = parts[0].toLowerCase();

  if (first === "admin" || first === "api") {
    const auth = checkAuth(request, env);
    if (auth === "unset") return html("<h1>Setup incomplete</h1><p>Set the ADMIN_PASSWORD secret. See README step 5.</p>", 503);
    if (auth !== "ok") {
      return new Response("Password required", {
        status: 401,
        headers: { ...BASE_HEADERS, "WWW-Authenticate": 'Basic realm="Plexus Admin", charset="UTF-8"', "Cache-Control": "no-store" },
      });
    }
    if (first === "admin") return html(ADMIN_HTML);
    return handleApi(request, env, url, parts);
  }

  if (!validSlug(first)) return html(notFoundPage(), 404);
  const c = await getClient(env, first);
  if (!c) return html(notFoundPage(), 404);

  const sub = (parts[1] || "").toLowerCase();

  if (!sub) return html(renderPage(c), 200, "public, max-age=60");

  const redirect = { review: reviewUrl(c), insta: instaUrl(c), chat: waUrl(c) }[sub];
  if (redirect) {
    return new Response(null, { status: 302, headers: { ...BASE_HEADERS, Location: redirect, "Cache-Control": "public, max-age=60" } });
  }

  if (sub === "logo" || sub === "banner") {
    const { value, metadata } = await env.CLIENTS.getWithMetadata(`img:${first}:${sub}`, { type: "arrayBuffer" });
    if (!value) return html(notFoundPage(), 404);
    return new Response(value, {
      headers: { ...BASE_HEADERS, "Content-Type": metadata?.type || "image/jpeg", "Cache-Control": "public, max-age=31536000, immutable" },
    });
  }

  return html(notFoundPage(), 404);
}
